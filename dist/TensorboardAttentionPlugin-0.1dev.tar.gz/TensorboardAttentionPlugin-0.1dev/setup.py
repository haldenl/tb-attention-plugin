from distutils.core import setup

setup(
    name='TensorboardAttentionPlugin',
    version='0.1dev',
    author='Halden Lin',
    packages=['attention_plugin'])
